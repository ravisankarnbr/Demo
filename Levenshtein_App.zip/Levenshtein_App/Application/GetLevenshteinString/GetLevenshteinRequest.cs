﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.GetLevenshteinString
{
    public class GetLevenshteinRequest : IRequest<GetLevenshteinResponse>
    {
        public string SourceString { get; set; }
        public string DestinationString { get; set; }
    }
}
