﻿using FluentValidation;
using FluentValidation.Validators;


namespace Application.GetLevenshteinString
{
    public class GetLevenshteinValidator : AbstractValidator<GetLevenshteinRequest>
    {
        public GetLevenshteinValidator()
        {
            CascadeMode = CascadeMode.StopOnFirstFailure;

            RuleFor(x => x.SourceString).NotEmpty().WithMessage("Input string cannot be empty.");
            RuleFor(x => x.DestinationString).NotEmpty().WithMessage("Input string cannot be empty.");
        }
    }
}
