﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.GetLevenshteinString
{
    public class GetLevenshteinResponse
    {
        public string LevenshteinString { get; set; }
    }
}
