﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.GetLevenshteinString;

namespace Application
{
    public interface IGetDistanceApi
    {
        Task<IEnumerable<GetLevenshteinResponse>> GetDistance();       
    }
}
