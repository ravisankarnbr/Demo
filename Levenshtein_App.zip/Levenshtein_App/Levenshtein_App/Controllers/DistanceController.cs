﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application.GetLevenshteinString;
using Microsoft.AspNetCore.Mvc;

namespace Levenshtein_App.Controllers
{
    public class DistanceController : BaseController
    {
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetLevenshteinResponse>>> GetLevenshteinDistance([FromQuery]GetLevenshteinRequest request)
        {
            var response = await Mediator.Send(request);

            return Ok(response);
        }
    }
}