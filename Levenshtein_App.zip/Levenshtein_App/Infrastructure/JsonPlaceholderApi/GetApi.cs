﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Application;
using Application.GetLevenshteinString;

namespace Infrastructure.JsonPlaceholderApi
{
    public class GetApi : IGetDistanceApi
    {
        private readonly JsonPlaceholderClient _client;

        public GetApi(JsonPlaceholderClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<GetLevenshteinResponse>> GetDistance()
        {
            return await _client.GetAllPosts();
        }
       
    }
}
