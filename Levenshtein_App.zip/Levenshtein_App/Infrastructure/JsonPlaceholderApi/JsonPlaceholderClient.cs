﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Application.GetLevenshteinString;


namespace Infrastructure.JsonPlaceholderApi
{
    public class JsonPlaceholderClient : BaseHttpClient
    {
        public JsonPlaceholderClient(HttpClient httpClient) : base(httpClient)
        {

        }

        public async Task<IEnumerable<GetLevenshteinResponse>> GetAllPosts()
        {
            return await Get<IEnumerable<GetLevenshteinResponse>>(Endpoints.Posts.GetAllPosts);
        }
    }
}

